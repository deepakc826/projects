<header class="main-header fixed-top">
    <div class="container">
        <div class="d-flex justify-content-between">
            <div class="logo align-self-center">
                <img src="assets/images/logo.png" class="img-fluid" alt="DHI Logo">
            </div>
            <div class="contact-btn align-self-center">
                <a class="btn btn-outline me-1" href="#">Book An Appointment</a>
                <a class="btn btn-outline" href="tel:1800 130 9300"><span class="button-icon"><i class="fas fa-phone-volume"></i></span> <span class="mobile-hidden">1800 130 9300</span></a>
            </div>
        </div>
    </div>
</header>