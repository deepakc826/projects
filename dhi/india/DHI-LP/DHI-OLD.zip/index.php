<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DHI</title>
    <!-- meta des -->
    <meta name="keywords" content="DHI">
    <meta name="description" content="DHI">
    <meta property="og:title" content="">
    <meta property="og:image" content="">
    <meta property="og:description" content="DHI">
    <!------------Website Theme Color---------------------->
    <!-- Chrome, Firefox OS and Opera -->
    <meta name="theme-color" content="#3A8291">
    <!-- Windows Phone -->
    <meta name="msapplication-navbutton-color" content="#3A8291">
    <!-- iOS Safari -->
    <meta name="apple-mobile-web-app-status-bar-style" content="#3A8291">
    <!---------------------- favicon ---------------------->
    <link rel="icon" href="assets/images/favicon.png">
    <!---------------------- css ---------------------->
    <link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css"
        href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.8.2/css/all.min.css">
    <link rel="stylesheet" type="text/css" href="assets/css/owl.carousel.min.css">
    <link rel="stylesheet" type="text/css" href="assets/css/stylesheet.css">
</head>

<body>
    <div class="wrapper">
        <!------------  header ----------->
        <?php include 'header.php';?>
        <!------------ // header ----------->
        <!------------ banner area --------->
        <section class="banner">
            <div class="container-fluid">
                <div class="banner-wrapper">
                    <div class="row align-items-center">
                        <div class="col-md-12 col-xl-7">
                            <div class="banner-heading-area">
                                <h5>Hair Implantation</h5>
                                <h1>Life-Changing,<br>Natural-Looking Results</h1>
                                <p>3,498 Hair Implanted In Six Hour</p>
                            </div>
                        </div>
                        <div class="col-md-12 col-xl-5">

                            <div class="counter-mobile-wrapper destop-hidden">
                                <div class="row">
                                    <div class="col-12">
                                        <div class="row align-items-center">
                                            <!-- 1 -->
                                            <div class="custom-col">
                                                <div class="transparent-white-bg">
                                                    <div class="d-flex justify-content-center">
                                                        <div class="box-icon me-3">
                                                            <img src="assets/images/calender.png" class="img-fluid"
                                                                alt="Years of experience">
                                                        </div>
                                                        <div class="box-container">
                                                            <h6>52</h6>
                                                            <p>Years</p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <!-- 2 -->
                                            <div class="custom-col">
                                                <div class="transparent-white-bg">
                                                    <div class="d-flex justify-content-center">
                                                        <div class="box-icon me-3">
                                                            <img src="assets/images/hospital.png" class="img-fluid"
                                                                alt="Years of experience">
                                                        </div>
                                                        <div class="box-container">
                                                            <h6>75</h6>
                                                            <p>Clinics</p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <!-- 3 -->
                                            <div class="custom-col">
                                                <div class="transparent-white-bg">
                                                    <div class="d-flex justify-content-center">
                                                        <div class="box-icon me-3">
                                                            <img src="assets/images/globe.png" class="img-fluid"
                                                                alt="Years of experience">
                                                        </div>
                                                        <div class="box-container">
                                                            <h6>45</h6>
                                                            <p>Countries</p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <!-- 4 -->
                                            <div class="custom-col custom-fifty">
                                                <div class="transparent-white-bg">
                                                    <div class="d-flex justify-content-center">
                                                        <div class="box-icon me-3">
                                                            <img src="assets/images/patients.png" class="img-fluid"
                                                                alt="Years of experience">
                                                        </div>
                                                        <div class="box-container">
                                                            <h6>300000 +</h6>
                                                            <p>Delighted Patients</p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <!-- 5 -->
                                            <div class="custom-col custom-fifty">
                                                <div class="transparent-white-bg">
                                                    <div class="d-flex justify-content-center">
                                                        <div class="box-icon me-3">
                                                            <img src="assets/images/bill.png" class="img-fluid"
                                                                alt="Years of experience">
                                                        </div>
                                                        <div class="box-container">
                                                            <h6>300 +</h6>
                                                            <p>Procedures Everyday</p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="banner-upper-form">
                                <div class="banner-title">
                                    <h2 class="text-center">BOOK A CONSULTATION WITH THE EXPERT NOW</h2>
                                </div>
                                <div class="main-form-area">
                                     <form action="<?php echo $link."call-us.php"; ?>" id="query-form" method="post" class="booking-form">
                                        <div class="form-group">
                                            <input type="text" class="form-control" name="name" id="name"
                                                placeholder="Name">
                                          	<span class="help-block" id="error-name"></span>
                                        </div>
                                        <div class="form-group">
                                            <input type="email" class="form-control" name="email" id="email"
                                                placeholder="E-Mail">
                                            <span class="help-block" id="error-email"></span>
                                        </div>
                                        <div class="form-group">
                                            <select class="location form-control form-select" name="location">
                                                <option value="">Preferred Location</option>
                                                <option value="australia">Australia</option>
                                                <option value="greece">Greece</option>
                                                <option value="jersey">Jersey</option>
                                                <option value="portugal">Portugal</option>
                                            </select>
                                            <span class="help-block" id="error-location"></span>
                                        </div>
                                        <div class="form-group">
                                            <input type="tel" class="form-control" name="phone" id="tel"
                                                placeholder="Mobile Number">
                                            <span class="help-block" id="error-phone"></span>
                                        </div>
                                        <div class="form-group">
                                            <button type="submit" class="btn btn-blue w-100" id="send_message">Book An Appointment</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!----------// banner area --------->

        <!---------- counter area --------->
        <section class="mobile-hidden">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="counter-wrapper">
                            <div class="row align-items-center">
                                <!-- 1 -->
                                <div class="custom-col">
                                    <div class="d-flex justify-content-center">
                                        <div class="box-icon me-3">
                                            <img src="assets/images/calender.png" class="img-fluid"
                                                alt="Years of experience">
                                        </div>
                                        <div class="box-container">
                                            <h6>52</h6>
                                            <p>Years</p>
                                        </div>
                                    </div>
                                </div>
                                <!-- 2 -->
                                <div class="custom-col">
                                    <div class="d-flex justify-content-center">
                                        <div class="box-icon me-3">
                                            <img src="assets/images/hospital.png" class="img-fluid"
                                                alt="Years of experience">
                                        </div>
                                        <div class="box-container">
                                            <h6>75</h6>
                                            <p>Clinics</p>
                                        </div>
                                    </div>
                                </div>
                                <!-- 3 -->
                                <div class="custom-col">
                                    <div class="d-flex justify-content-center">
                                        <div class="box-icon me-3">
                                            <img src="assets/images/globe.png" class="img-fluid"
                                                alt="Years of experience">
                                        </div>
                                        <div class="box-container">
                                            <h6>45</h6>
                                            <p>Countries</p>
                                        </div>
                                    </div>
                                </div>
                                <!-- 4 -->
                                <div class="custom-col">
                                    <div class="d-flex justify-content-center">
                                        <div class="box-icon me-3">
                                            <img src="assets/images/patients.png" class="img-fluid"
                                                alt="Years of experience">
                                        </div>
                                        <div class="box-container">
                                            <h6>300000 +</h6>
                                            <p>Delighted Patients</p>
                                        </div>
                                    </div>
                                </div>
                                <!-- 5 -->
                                <div class="custom-col">
                                    <div class="d-flex justify-content-center">
                                        <div class="box-icon me-3">
                                            <img src="assets/images/bill.png" class="img-fluid"
                                                alt="Years of experience">
                                        </div>
                                        <div class="box-container">
                                            <h6>300 +</h6>
                                            <p>Procedures Everyday</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--------// counter area --------->

        <!------------ space area --------->
        <!-- <div class="space"></div> -->
        <!---------/// space area --------->

        <!-------- treatment area --------->
        <section class="section-area treatment-area">
            <div class="container">
                <div class="row">
                <div class="col-12">
                    <div class="main-heading-area text-center">
                    <h6>Safety | Maximum Density | Natural Results</h6>
                    <h2>Treatment Patients Results</h2>
                    <p class="col-md-12 col-xl-8 mx-auto">At DHI, our objective is to bring you the latest and the most effective techniques in hair transplant, ensuring the highest level of care and attention.</p>
                    </div>
                </div>
                </div>
                <div class="row my-3">
                <div class="col-md-12 col-xl-5">
                    <div class="video-review-area">
                    <video class="treatment-video" width="100%" height="250" poster="assets/images/video-poster.png" controls autoplay loop>
                        <source src="assets/video/movie.mp4" type="video/mp4">
                    </video>
                    </div>
                </div>
                <div class="col-md-12 col-xl-7">
                    <div class="image-review-area">
                    <div id="treatment-carousel" class="owl-carousel">
                        <div class="item owl-box">
                        <a class="swap" href="#">
                            <img src="assets/images/t-1.png">
                            <img src="assets/images/t-2.png">
                        </a>
                        </div>
                        <div class="item owl-box">
                        <a class="swap" href="#">
                            <img src="assets/images/t-1.png">
                            <img src="assets/images/t-2.png">
                        </a>
                        </div>
                        <div class="item owl-box">
                        <a class="swap" href="#">
                            <img src="assets/images/t-1.png">
                            <img src="assets/images/t-2.png">
                        </a>
                        </div>
                        <div class="item owl-box">
                        <a class="swap" href="#">
                            <img src="assets/images/t-1.png">
                            <img src="assets/images/t-2.png">
                        </a>
                        </div>
                    </div>
                    </div>
                </div>
                </div>
            </div>
        </section>
        <!--------// treatment area-------->
          
         <!-------- technique area --------->
        <section class="section-area technique-area">
            <div class="container">
                <div class="technique-wrapper">
                    <div class="row align-items-center">
                        <div class="col-md-12 col-xl-6 m-0 p-0">
                            <div class="main-heading-area text-left technique-content">
                                <h6>Technique</h6>
                                <h2>Get Hair Naturally With DHI –</h2>
                                <h3>World`s Finest Hair Transplant Technique</h3>
                                <p>
                                    At DHI, our objective is to bring you the latest and the most 
                                    effective techniques in hair transplant ensuring the highest 
                                    level of care and attention.
                                </p>
                                <p>
                                    As one of the best hair transplant centres in India, 
                                    we provide you with all the information about hair 
                                    transplant which helps you understand the right hair 
                                    fall treatment for you. This, in turn, allows you to make an 
                                    informed choice based on your needs and goals.
                                </p>
                            </div>
                        </div>
                        <div class="col-md-12 col-xl-6 m-0 p-0">
                            <div class="technique-img"></div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--------// technique area --------->

        <!---------- table area --------->
         <section class="section-area table-area">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 col-xl-4 p-0 text-center">
                        <div class="table-main-heading">
                            <h2 class="dark-color"><b>FUE</b></h2>
                        </div>
                        <div class="white-table">
                            <div class="table-heading-title">
                                <h4>Follicular<br>Unit Extraction</h4>
                            </div>
                            <div class="table-list">
                                <ul>
                                    <li>Virtually painless procedure</li>
                                    <li>Slits are made</li>
                                    <li>No control on angle, depth & direction - unnatural results</li>
                                    <li>No written protocol followed</li>
                                    <li>Scars are left on scalp</li>
                                    <li>Low graft survival</li>
                                    <li>Recovery: 2-3 days</li>
                                    <li>Performed by multiple technicians, results in high graft handling & follicle damage</li>
                                </ul>
                            </div>
                            <div class="table-footer"></div>
                        </div>
                    </div>
                    <div class="col-md-12 col-xl-4 p-0 text-center">
                        <div class="table-main-heading">
                            <h2 class="light-color"><b>DHI</b></h2>
                        </div>
                        <div class="dark-table">
                            <div class="table-heading-title-dark">
                                <h4>Direct<br>Hair Implantation</h4>
                            </div>
                            <div class="table-list">
                                <ul>
                                    <li>Painless procedure</li>
                                    <li>Cuts are made</li>
                                    <li>No control on angle, depth & direction - unnatural results</li>
                                    <li>No written protocol followed</li>
                                    <li>Leaves a prominent scar</li>
                                    <li>Very low graft survival</li>
                                    <li>Recovery: 2 weeks</li>
                                    <li>Performed by multiple technicians, results in high graft handling & follicle damage</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-12 col-xl-4 p-0 text-center">
                        <div class="table-main-heading">
                            <h2 class="dark-color"><b>FUT</b></h2>
                        </div>
                        <div class="white-table">
                            <div class="table-heading-title">
                                <h4>Follicular<br>Unit Transplantation</h4>
                            </div>
                            <div class="table-list">
                                <ul>
                                    <li>Painless procedure</li>
                                    <li>Cuts are made</li>
                                    <li>No control on angle, depth & direction - unnatural results</li>
                                    <li>No written protocol followed</li>
                                    <li>Leaves a prominent scar</li>
                                    <li>Very low graft survival</li>
                                    <li>Recovery: 2 weeks</li>
                                    <li>Performed by multiple technicians, results in high graft handling & follicle damage</li>
                                </ul>
                            </div>
                            <div class="table-footer"></div>
                        </div>
                    </div>
                </div>
            </div>
         </section>   

        <!--------// table area ---------> 

        <!-------- technique area --------->
        <section class="section-area technique-area">
            <div class="container">
                <div class="technique-wrapper">
                    <div class="row">

                    </div>
                </div>
            </div>
        </section>
        <!--------// technique area --------->

        <!------------ location ------------>
        <section class="section-area location-area">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-md-12 col-xl-6">
                        <div class="left-section">
                            <div class="main-heading-area">
                                <h6>Location</h6>
                                <h2>Our Presence Around The World</h2>
                            </div>
                            <div class="button-group">
                                <a href="#" class="btn btn-light-bg">NATIONAL PRESENCE</a>
                                <a href="#" class="btn btn-dark-bg">GLOBAL PRESENCE</a>
                            </div>
                            <div class="country-list">
                                <ul class="list-unstyled">
                                    <li class="list-inline-item"><span class="dashed"></span> Australia</li>
                                    <li class="list-inline-item"><span class="dashed"></span> Greece</li>
                                    <li class="list-inline-item"><span class="dashed"></span> Jersey</li>
                                    <li class="list-inline-item"><span class="dashed"></span> Portugal</li>
                                </ul>
                                <ul class="list-unstyled">
                                    <li class="list-inline-item"><span class="dashed"></span> Bahrain</li>
                                    <li class="list-inline-item"><span class="dashed"></span> Hong Kong</li>
                                    <li class="list-inline-item"><span class="dashed"></span> Morocco</li>
                                    <li class="list-inline-item"><span class="dashed"></span> Qatar</li>
                                </ul>
                                <ul class="list-unstyled">
                                    <li class="list-inline-item"><span class="dashed"></span> Belgium</li>
                                    <li class="list-inline-item"><span class="dashed"></span> India</li>
                                    <li class="list-inline-item"><span class="dashed"></span> Mauritius</li>
                                    <li class="list-inline-item"><span class="dashed"></span> Dubai</li>
                                </ul>
                                <ul class="list-unstyled">
                                    <li class="list-inline-item"><span class="dashed"></span> Bulgaria</li>
                                    <li class="list-inline-item"><span class="dashed"></span> Indonesia</li>
                                    <li class="list-inline-item"><span class="dashed"></span> Malaysia</li>
                                    <li class="list-inline-item"><span class="dashed"></span> Switzerland</li>
                                </ul>
                                <ul class="list-unstyled">
                                    <li class="list-inline-item"><span class="dashed"></span> Colombia</li>
                                    <li class="list-inline-item"><span class="dashed"></span> Isle Of Man</li>
                                    <li class="list-inline-item"><span class="dashed"></span> Netherlands</li>
                                    <li class="list-inline-item"><span class="dashed"></span> Paris</li>
                                </ul>
                                <ul class="list-unstyled">
                                    <li class="list-inline-item"><span class="dashed"></span> Egypt</li>
                                    <li class="list-inline-item"><span class="dashed"></span> Ireland</li>
                                    <li class="list-inline-item"><span class="dashed"></span> Canada</li>
                                    <li class="list-inline-item"><span class="dashed"></span> United Kingdom</li>
                                </ul>
                                <ul class="list-unstyled">
                                    <li class="list-inline-item"><span class="dashed"></span> France</li>
                                    <li class="list-inline-item"><span class="dashed"></span> Italy</li>
                                    <li class="list-inline-item"><span class="dashed"></span> Panama</li>
                                    <li class="list-inline-item"><span class="dashed"></span> Mexico</li>
                                </ul>
                                <ul class="list-unstyled">
                                    <li class="list-inline-item"><span class="dashed"></span> Germany</li>
                                    <li class="list-inline-item"><span class="dashed"></span> Jordan</li>
                                    <li class="list-inline-item"><span class="dashed"></span> Philippines</li>
                                    <li class="list-inline-item"><span class="dashed"></span> Brazil</li>
                                </ul>
                                <ul class="list-unstyled">
                                    <li class="list-inline-item"><span class="dashed"></span> Sri Lanka</li>
                                    <li class="list-inline-item"><span class="dashed"></span> United Arab Emirates</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-12 col-xl-6">
                        <div class="image-area">
                            <img src="assets/images/map.png" class="img-fluid" alt="Globe">
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!------------// location ---------->

        <!-------------- footer ------------>
        <?php include 'footer.php';?>
        <!-------------// footer ----------->
    </div>
    <!---wrapper div-->
    <!---------------------- js ---------------------->
    <script src="assets/js/jquery-3.7.0.min.js"></script>
    <script src="assets/js/popper.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/owl.carousel.min.js"></script>
    <script src="assets/js/custom.js"></script>
    <script src="assets/js/custom/script.js"></script>
      
</body>

</html>