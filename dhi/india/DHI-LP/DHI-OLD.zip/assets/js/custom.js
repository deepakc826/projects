//Back to top
$(window).scroll(function () {
       var height = $(window).scrollTop();
       if (height > 100) {
       $('#back-to-top').fadeIn();
       } else {
       $('#back-to-top').fadeOut();
       }
});
$(document).ready(function () {
       $("#back-to-top").click(function (event) {
       event.preventDefault();
       $("html, body").animate({
       scrollTop: 0
       }, "slow");
       return false;
       });
});
// treatment
jQuery("#treatment-carousel").owlCarousel({
       autoplay: true,
       lazyLoad: true,
       loop: true,
       margin: 20,
       responsiveClass: true,
       autoHeight: true,
       autoplayTimeout: 7000,
       smartSpeed: 800,
       dots: true,
       nav: true,
       responsive: {
         0: {
           items: 2
         },
     
         600: {
           items: 2
         },
     
         1024: {
           items: 2
         },
     
         1366: {
           items: 2
         }
       }
     });
//For Firefox we have to handle it in JavaScript 
var vids = $("video"); 
$.each(vids, function(){
       this.controls = false; 
}); 
//Loop though all Video tags and set Controls as false

$("video").click(function() {
  //console.log(this); 
  if (this.paused) {
    this.play();
  } else {
    this.pause();
  }
});